package introsde.assignment.soap.document.model;

import java.io.Serializable;
import javax.persistence.*;
import java.util.Date;


/**
 * The persistent class for the "Measure" database table.
 * 
 */
@Entity
@Table(name="\"Measure\"")
@NamedQuery(name="Measure.findAll", query="SELECT m FROM Measure m")
public class Measure implements Serializable {
	private static final long serialVersionUID = 1L;

	@Temporal(TemporalType.DATE)
	@Column(name="\"dateRegistered\"")
	private Date dateRegistered;

	@Column(name="\"idMeasure\"")
	private int idMeasure;

	@Column(name="\"type\"")
	private String type;

	@Column(name="\"value\"")
	private String value;

	@Column(name="\"valueType\"")
	private int valueType;

	//bi-directional many-to-one association to Person
	@ManyToOne
	@JoinColumns({
		})
	private Person person;

	public Measure() {
	}

	public Date getDateRegistered() {
		return this.dateRegistered;
	}

	public void setDateRegistered(Date dateRegistered) {
		this.dateRegistered = dateRegistered;
	}

	public int getIdMeasure() {
		return this.idMeasure;
	}

	public void setIdMeasure(int idMeasure) {
		this.idMeasure = idMeasure;
	}

	public String getType() {
		return this.type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return this.value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public int getValueType() {
		return this.valueType;
	}

	public void setValueType(int valueType) {
		this.valueType = valueType;
	}

	public Person getPerson() {
		return this.person;
	}

	public void setPerson(Person person) {
		this.person = person;
	}

}